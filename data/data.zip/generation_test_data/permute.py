import numpy as np
import torch
import os
import argparse



def dists_and_qs(filename=""):
    print(os.path.isfile(filename))
    f = open(filename, "r")
    lines = f.readlines()
    f.close()
    dists_file = open("dists_"+filename, "w")
    quests_file = open("quests_"+filename, "w")
    for l in lines:
        split_lines = l.split(" ")
        dists_file.write(split_lines[1]+"\n")
        g_index = split_lines.index("<G>")
        quests_file.write(" ".join(split_lines[g_index+1:-1])+"\n")
    dists_file.close()
    quests_file.close()

#rand1: only shuffle confidence values
def rand1(filename=""):
    f = open(filename, "r")
    lines = f.readlines()
    f.close()
    dists_file = open("dists_"+filename, "r")
    dists = dists_file.readlines()
    dists = [float(d) for d in dists]
    dists_file.close()
    new_f = open("rand1_"+filename, "w")
    for l in lines:
        split_lines = l.split(" ")
        split_lines[1] = str(dists.pop(np.random.randint(len(dists))))
        new_f.write(" ".join(split_lines))
    new_f.close()

#rand2: only shuffle questions
def rand2(filename=""):
    f = open(filename, "r")
    lines = f.readlines()
    f.close()
    quests_file = open("quests_"+filename, "r")
    quests = quests_file.readlines()
    quests = [q.replace("\n","") for q in quests]
    quests_file.close()
    new_f = open("rand2_"+filename, "w")
    for l in lines:
        split_lines = l.split(" ")
        g_index = split_lines.index("<G>")
        new_line = " ".join(split_lines[:g_index+1])+" "+quests.pop(np.random.randint(len(quests)))+" <EOS>"
        new_f.write(new_line+"\n")
    new_f.close()

#rand2: shuffle both confidence and questions
def rand3(filename=""):
    f = open(filename, "r")
    lines = f.readlines()
    f.close()
    quests_file = open("quests_"+filename, "r")
    quests = quests_file.readlines()
    quests = [q.replace("\n","") for q in quests]
    quests_file.close()
    dists_file = open("dists_"+filename, "r")
    dists = dists_file.readlines()
    dists = [float(d) for d in dists]
    dists_file.close()
    new_f = open("rand3_"+filename, "w")
    for l in lines:
        split_lines = l.split(" ")
        split_lines[1] = str(dists.pop(np.random.randint(len(dists))))
        g_index = split_lines.index("<G>")
        new_line = " ".join(split_lines[:g_index+1])+" "+quests.pop(np.random.randint(len(quests)))+" <EOS>"
        new_f.write(new_line+"\n")
    new_f.close()

#effectively permute student
def rand4(filename=""):
    f = open(filename, "r")
    lines = f.readlines()
    f.close()
    quests_file = open("quests_"+filename, "r")
    quests = quests_file.readlines()
    quests = [q.replace("\n","") for q in quests]
    quests_file.close()
    dists_file = open("dists_"+filename, "r")
    dists = dists_file.readlines()
    dists = [float(d) for d in dists]
    dists_file.close()
    new_f = open("rand4_"+filename, "w")
    for l in lines:
        split_lines = l.split(" ")
        rand_val = np.random.randint(len(dists))
        split_lines[1] = str(dists.pop(rand_val))
        g_index = split_lines.index("<G>")
        new_line = " ".join(split_lines[:g_index+1])+" "+quests.pop(rand_val)+" <EOS>"
        new_f.write(new_line+"\n")
    new_f.close()

parser = argparse.ArgumentParser(description='Process some strings.')
parser.add_argument('-f', '--truefile')
args = parser.parse_args()

dists_and_qs(args.truefile)
rand1(args.truefile)
rand2(args.truefile)
rand3(args.truefile)
rand4(args.truefile)
